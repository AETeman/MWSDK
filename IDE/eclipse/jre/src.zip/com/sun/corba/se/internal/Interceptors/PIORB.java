/*
 * Copyright (c) 2000, 2003, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
package com.sun.corba.se.internal.Interceptors;

import com.sun.corba.se.internal.POA.POAORB;

/**
 * Deprecated class for backward compatibility.
 */
public class PIORB
    extends POAORB
{
    public PIORB() {
        super();
    }
}

// End of file.
